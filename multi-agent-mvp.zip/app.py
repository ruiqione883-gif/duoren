from orchestrator import MultiAgentSystem

def main():
    system = MultiAgentSystem()

    while True:
        user_input = input("\n请输入你的运营目标（输入exit退出）：\n> ")

        if user_input.lower() == "exit":
            break

        result = system.run(user_input)

        print("\n====================")
        print(result)


if __name__ == "__main__":
    main()
