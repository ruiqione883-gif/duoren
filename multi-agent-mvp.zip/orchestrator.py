from agents import manager_agent, worker_agent, reviewer_agent


class MultiAgentSystem:

    def __init__(self):
        self.memory = []

    def run(self, user_task):
        print("\n🚀 多Agent系统启动\n")

        print("🧠 Manager处理中...")
        tasks = manager_agent.run(user_task)
        self.memory.append(tasks)

        print("⚙️ Worker执行中...")
        execution = worker_agent.run(tasks)
        self.memory.append(execution)

        print("🔍 Reviewer优化中...")
        final = reviewer_agent.run(execution)

        print("\n✅ 完成\n")
        return final
