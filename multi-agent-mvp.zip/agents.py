from openai import OpenAI
from config import OPENAI_API_KEY, MODEL_NAME

client = OpenAI(api_key=OPENAI_API_KEY)


class Agent:
    def __init__(self, name, system_prompt):
        self.name = name
        self.system_prompt = system_prompt

    def run(self, message, context=""):
        response = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": f"{message}\n\n上下文:\n{context}"}
            ]
        )
        return response.choices[0].message.content


manager_agent = Agent(
    "Manager",
    "你是运营策略专家，把用户目标拆解成JSON数组任务列表"
)

worker_agent = Agent(
    "Worker",
    "你是执行型运营人员，根据任务输出详细执行方案"
)

reviewer_agent = Agent(
    "Reviewer",
    "你是审核优化专家，输出最终高质量版本"
)
