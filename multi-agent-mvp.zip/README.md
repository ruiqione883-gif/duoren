# Multi-Agent MVP

## 🚀 启动步骤

### 1. 安装依赖
pip install -r requirements.txt

### 2. 设置API Key
export OPENAI_API_KEY=你的key

### 3. 运行
python app.py

## 🧠 示例输入
做一个小红书涨粉方案

## 🏗 架构
Manager → Worker → Reviewer
