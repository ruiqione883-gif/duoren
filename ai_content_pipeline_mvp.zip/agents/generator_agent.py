
class GeneratorAgent:
    def run(self, storyboard):
        content = []
        for s in storyboard:
            content.append(f"生成画面: {s}")
        print("内容生成完成")
        return content
