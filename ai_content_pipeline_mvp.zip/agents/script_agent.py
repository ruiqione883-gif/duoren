
class ScriptAgent:
    def run(self, topic):
        script = f"这是一个关于【{topic}】的短视频脚本，包含开头吸引、中间干货、结尾转化。"
        print("脚本生成完成")
        return script
