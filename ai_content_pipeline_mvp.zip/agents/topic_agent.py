
import random

class TopicAgent:
    def run(self):
        topics = ["AI选房技巧", "副业赚钱思路", "短视频爆款逻辑", "商标设计趋势"]
        topic = random.choice(topics)
        print(f"选题: {topic}")
        return topic
