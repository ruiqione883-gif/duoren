
class OptimizeAgent:
    def run(self, content):
        optimized = [c + "（优化后）" for c in content]
        print("内容优化完成")
        return optimized
