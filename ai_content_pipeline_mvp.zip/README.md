
# 多Agent内容生产流水线（MVP）

## 简介
一个模拟短视频/内容生产的多Agent系统，包含选题→脚本→分镜→生成→优化全流程。

## Agent
- TopicAgent
- ScriptAgent
- StoryboardAgent
- GeneratorAgent
- OptimizeAgent

## 运行
python main.py

## 可扩展
- 接入GPT/Claude生成脚本
- 接入Stable Diffusion / 视频生成模型
- 加入数据反馈闭环优化
