
from agents.topic_agent import TopicAgent
from agents.script_agent import ScriptAgent
from agents.storyboard_agent import StoryboardAgent
from agents.generator_agent import GeneratorAgent
from agents.optimize_agent import OptimizeAgent

def main():
    topic_agent = TopicAgent()
    script_agent = ScriptAgent()
    storyboard_agent = StoryboardAgent()
    generator_agent = GeneratorAgent()
    optimize_agent = OptimizeAgent()

    topic = topic_agent.run()
    script = script_agent.run(topic)
    storyboard = storyboard_agent.run(script)
    content = generator_agent.run(storyboard)
    final = optimize_agent.run(content)

    print("\n=== 最终内容 ===")
    print(final)

if __name__ == "__main__":
    main()
